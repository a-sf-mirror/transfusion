#include <math.h>
#include <stdio.h>

#ifdef _MSC_VER
#pragma warning (disable:4244)
#endif

void G_2va(long x1, long y1, long x2, long y2, long *x, long *y)
{
 double x_1, y_1, x_2, y_2, v2x, v2y, k, sinq;
 long v1x, v1y;

 v1x = x2 - x1;
 v1y = y2 - y1;

 y_1 = 0.5/(v1y*v1y+v1x*v1x)*(2*y1*v1x*v1x+2*v1y*v1y*y1+2*sqrt(10*v1y*v1y*v1x*v1x+10*v1x*v1x*v1x*v1x));
 x_1 = (v1x*x1-v1y*y_1+v1y*y1) / v1x;
 y_2 = 0.5/(v1y*v1y+v1x*v1x)*(2*y1*v1x*v1x+2*v1y*v1y*y1-2*sqrt(10*v1y*v1y*v1x*v1x+10*v1x*v1x*v1x*v1x));
 x_2 = (v1x*x1-v1y*y_2+v1y*y1) / v1x;

 //printf("%f,%f\n", x_1, y_1);
 //printf("%f,%f\n", x_2, y_2);
 //printf("---------\n");
             
 v2x  = x_1 - x1;
 v2y  = y_1 - y1;                    
 k    = v1x*v2y - v1y*v2x;
 sinq = k / sqrt(v1x*v1x + v1y*v1y) / sqrt(v2x*v2x + v2y*v2y);
// printf("%f\n", sinq);
 if (sinq == -1)
 {
  *x = x_1 +10;
  *y = y_1 +10; 
 } else
 {
  *x = x_2 +10;
  *y = y_2 +10; 
 }
}


/*
main ()
{
 long x;
 long y;

 G_2va(0, 0,  5, 5, &x, &y);


 printf("[%ld,%ld]\n", x, y);

 return 0;
}
*/