#include "global.h"

void DrawSky(FILE *f)
{
 int  i;
 long Max_H = -4090, Max_X = -4090, Max_Y = -4090, Min_H =  4090, Min_X =  4090, Min_Y =  4090;
 
 printf("I_Sky  : Making Sky...\n");

 for (i = 0; i < numsectors; i++)
 {
  if (sector[i].ceilingz > Max_H) Max_H = sector[i].ceilingz;
  if (sector[i].floorz   < Min_H) Min_H = sector[i].floorz  ;
 }

 for (i = 0; i < numwalls; i++)
 {
  if (wall[i].x > Max_X) Max_X = wall[i].x;
  if (wall[i].y > Max_Y) Max_Y = wall[i].y;
  if (wall[i].x < Min_X) Min_X = wall[i].x;
  if (wall[i].y < Min_Y) Min_Y = wall[i].y;
 }

 if (Max_X >  4090) Max_X =  3890;
 if (Max_Y >  4090) Max_Y =  3890;
 if (Min_X < -4090) Min_X = -3890;
 if (Min_Y < -4090) Min_Y = -3890;

 Max_H += 10;
 Max_X += 10;
 Max_Y += 10;
 Min_H -= 10;
 Min_X -= 10;
 Min_Y -= 10;

 fprintf(f,"// Sky ==>>\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0,    0,   Max_H+16,       0,  500,   Max_H+16,     500,    0,   Max_H+16);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X,    0,      0,    Max_X,    0,    500,    Max_X,  500,      0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0, Min_Y,      0,       0, Min_Y,    500,     500, Min_Y,      0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X,    0,      0,    Min_X,  500,      0,    Min_X,    0,    500);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0, Max_Y,      0,     500, Max_Y,      0,       0, Max_Y,    500);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0,    0, Max_H,     500,    0, Max_H,       0,  500, Max_H);
 fprintf(f, " }\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0,    0,   Min_H,       0,  500,   Min_H,     500,    0,   Min_H);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X,    0,      0,    Max_X,    0,    500,    Max_X,  500,      0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0, Min_Y,      0,       0, Min_Y,    500,     500, Min_Y,      0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X,    0,      0,    Min_X,  500,      0,    Min_X,    0,    500);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0, Max_Y,      0,     500, Max_Y,      0,       0, Max_Y,    500);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0,    0, Min_H-16,     500,    0, Min_H-16,       0,  500, Min_H-16);
 fprintf(f, " }\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Max_H,       0, 500, Max_H,     500, 0, Max_H);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Max_Y+16, 500,     Min_X, Max_Y+16, 500,    Min_X, Max_Y+16, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Max_Y+16, 500,     Min_X, Max_Y, 500,      Min_X, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Max_Y, 500,       Max_X, Max_Y, 500,      Max_X, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Max_Y, 500, Max_X, Max_Y+16, 500, Max_X, Max_Y+16, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n",    0,      0, Min_H,     500,      0, Min_H,       0,    500, Min_H);
 fprintf(f, " }\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Max_H,  0, 500, Max_H,  500, 0, Max_H);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Min_Y,  500,  Min_X, Min_Y,  500,  Min_X, Min_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Min_Y,    500,  Min_X, Min_Y-16,  500,  Min_X, Min_Y-16, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Min_Y-16,  500,  Max_X, Min_Y-16,  500,  Max_X, Min_Y-16, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Min_Y-16,  500,  Max_X, Min_Y,    500,  Max_X, Min_Y,   0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Min_H,  500, 0, Min_H,  0, 500, Min_H);
 fprintf(f, " }\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Max_H,  0, 500, Max_H,  500, 0, Max_H);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Min_Y, 500,    Min_X, Max_Y, 500,    Min_X, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X, Max_Y, 500,    Min_X-16, Max_Y, 500,  Min_X-16, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X-16, Max_Y, 500,  Min_X-16, Min_Y, 500,  Min_X-16, Min_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Min_X-16, Min_Y, 500,  Min_X, Min_Y, 500, Min_X, Min_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Min_H,  500, 0, Min_H,  0, 500, Min_H);
 fprintf(f, " }\n");

 fprintf(f, " {\n");
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Max_H,  0, 500, Max_H,  500, 0, Max_H);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Max_Y,  500,  Max_X, Min_Y,  500,  Max_X, Min_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X, Min_Y,  500,  Max_X+16,   Min_Y,  500,  Max_X+16,   Min_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X+16, Min_Y,  500,  Max_X+16, Max_Y,  500,  Max_X+16, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", Max_X+16,   Max_Y,  500,  Max_X, Max_Y,  500,  Max_X, Max_Y, 0);
 fprintf(f, "  ( %d  %d  %d ) ( %d  %d  %d ) ( %d  %d  %d ) e1u2/sky1 0 0 0 1.00 1.00 0 133 1\n", 0, 0, Min_H,  500, 0, Min_H,  0, 500, Min_H);
 fprintf(f, " }\n");

 fprintf(f, "// <<== Sky\n");
 printf("Done\n");
}
