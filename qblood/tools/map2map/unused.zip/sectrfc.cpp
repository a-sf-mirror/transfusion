/*
#include <stdio.h>
#include "global.h"
#include "s_sector.h"

void WriteFloor  (FILE *f, long SectorNumber, long Plus);
void WriteCeiling(FILE *f, long SectorNumber, long Plus);
void W_Floor2(FILE *f, long i, long Plus);
void W_Ceil2(FILE *f, long i, long Plus);
void W_Sector_II(FILE *f, long SectorNumber, long Up, long Dn);
void DrawSectorWalls(FILE *f, long i);


void DrawFloor(FILE *f, long i)
{


 int  j;
 long Dn = -15, Up = 1, wallpointer, ST, SB;

 ST  = sector[i].floorz;
 SB  = sector[i].ceilingz;
 wallpointer = sector[i].wallptr;
 j   = sector[i].wallptr; //wall[wallpointer].point2;
 
 do 
 {
  if (wall[j].nextsector != -1)
  {
   if (sector[wall[j].nextsector].floorz - ST < Dn)
   {
    Dn = sector[wall[j].nextsector].floorz - ST;
   } 






   if ((sector[wall[j].nextsector].ceilingz - SB > Up) & (sector[wall[j].nextsector].ceilingz != sector[wall[j].nextsector].floorz))
   {
    Up = sector[wall[j].nextsector].ceilingz - SB;
   }


   M_Wall[               j] = 1;
   M_Wall[wall[j].nextwall] = 1;
  }
  j = wall[j].point2;
 } while (j != wallpointer);


 if (FindWalls(i) != sector[i].wallnum)
 {
  W_Sector_II(f, i, Up, Dn);
//  W_Floor2(f, i, Dn);
//  W_Ceil2(f, i, Up);
 } else
 {
  WriteFloor  (f, i, Dn);
  WriteCeiling(f, i, Up);
  DrawSectorWalls(f, i);
 }
}
*/