/*
Copyright (C) 2001-2002 Timothy Hale <timhale@planetblood.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "global.h"
#include "names.h"

/* This is Duke 3d specific, re-implement in duke.c, and figure out how to do it for blood
 if (sprite[i].lotag == 3) SpawnFlag =  768;
 if (sprite[i].lotag == 2) SpawnFlag =  256; // not in easy
 if (sprite[i].lotag == 1) SpawnFlag =    0;
 if (sprite[i].pal   == 1) SpawnFlag = 1792;
*/

void Duke3D_To_Quake2 (unsigned short i, FILE *f)
{
	switch (sprite[i].picnum)
	{

	case FIRSTGUNSPRITE:	//21
	case CHAINGUNSPRITE:	//22
    WriteSimpleItem(i, "weapon_lightning", f);
    return;
	
	case RPGSPRITE:			//23 
	WriteSimpleItem(i, "weapon_rocketlauncher", f);
    return;

	case FREEZESPRITE:		//24 
	WriteSimpleItem(i, "weapon_plasmagun", f);
    return;

	case SHRINKERSPRITE:	//25 
	WriteSimpleItem(i, "weapon_railgun", f);
    return;

	case HEAVYHBOMB:		//26
	case DEVISTATORAMMO:	//42
	case HBOMBAMMO:			//47
	WriteSimpleItem(i, "ammo_grenades", f);
    return;

	case TRIPBOMBSPRITE:	//27	
	WriteSimpleItem(i, "weapon_bfg", f);
    return;

    case SHOTGUNSPRITE:		//28	
	WriteSimpleItem(i, "weapon_shotgun", f);
    return;

    case DEVISTATORSPRITE:	//29	
	WriteSimpleItem(i, "weapon_grenadelauncher", f);
    return;

	case FREEZEAMMO:		//37	
	WriteSimpleItem(i, "ammo_cells", f);
    return;

    case AMMO:				//40	
	WriteSimpleItem(i, "ammo_bullets", f);
    return;

    case BATTERYAMMO:		//41	
	WriteSimpleItem(i, "ammo_lightning", f);
    return;

    case RPGAMMO:		    //44	
	WriteSimpleItem(i, "ammo_rockets", f);
    return;

	case GROWAMMO:		    //45
	case CRYSTALAMMO:	    //46
	WriteSimpleItem(i, "ammo_slugs", f);
    return;

	case SHOTGUNAMMO:	    //49
	WriteSimpleItem(i, "ammo_shells", f);
    return;

	case COLA:				//51
	WriteSimpleItem(i, "item_health_small", f);
    return;

    case SIXPAK:			//52
	WriteSimpleItem(i, "item_health_large", f);
    return;

	case FIRSTAID:			//53
	WriteSimpleItem(i, "holdable_medkit", f);
    return;

	case SHIELD:			//54
	WriteSimpleItem(i, "item_armor_combat", f);
    return;
    
	case STEROIDS:			//55
	WriteSimpleItem(i, "item_armor_body", f);
    return;

	case AIRTANK:			//56
	WriteSimpleItem(i, "item_breather", f);
    return;

	case JETPACK:			//57
	WriteSimpleItem(i, "item_pack", f);
    return;

	case HEATSENSOR:		//59
	WriteSimpleItem(i, "item_silencer", f);
    return;

	case ACCESSCARD:		//60
	WriteSimpleItem(i, "key_blue_key", f);
    return;

	case BOOTS:				//61
	WriteSimpleItem(i, "item_enviro", f);
    return;

	case ATOMICHEALTH:		//100
	WriteSimpleItem(i, "item_health_mega", f);
    return;

	case HOLODUKE:			//1348
	WriteSimpleItem(i, "item_power_shield", f);
    return;

	case APLAYERTOP:		//1400
	case APLAYER:			//1405
	case PLAYERONWATER:		//1420 The player starts
		
		if (sprite[i].lotag == 1)
			WriteSimpleItem(i, "info_player_coop", f);
		else  
			WriteSimpleItem(i, "info_player_deathmatch", f);
		return;
 
	case   OOZFILTER:		//1079
	case     SEENINE:		//1247
	return;

	case MUSICANDSFX: 
	W_MusicanDSFX(i, "target_speaker", f); // TESTME:

	default:
    WriteSimpleItem(i, "fix_me", f); // Dummy entity
	} // switch

}