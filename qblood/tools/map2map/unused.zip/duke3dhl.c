/*
Copyright (C) 2001-2002 Timothy Hale <timhale@planetblood.com>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "global.h"
#include "names.h"

void Duke3D_To_HalfLife (unsigned short i, FILE *f)
{
	switch (sprite[i].picnum)
	{

	case FIRSTGUNSPRITE:	//21
	    W_OtherItems(i, "weapon_357", f);
    return;

	case CHAINGUNSPRITE:	//22
		W_OtherItems(i, "weapon_9mmAR", f);
	return;

   	case RPGSPRITE:			//23 
		W_OtherItems(i, "weapon_rpg", f);
    return;

	case FREEZESPRITE:		//24 
		W_OtherItems(i, "weapon_egon", f);
    return;

	case SHRINKERSPRITE:	//25 
		W_OtherItems(i, "weapon_hornetgun", f);
    return;

	case HEAVYHBOMB:		//26
	case DEVISTATORAMMO:	//42
	case HBOMBAMMO:			//47
		W_OtherItems(i, "weapon_handgrenade", f);
    return;

	case TRIPBOMBSPRITE:	//27	
		W_OtherItems(i, "weapon_tripmine", f);
    return;

    case SHOTGUNSPRITE:		//28	
		W_OtherItems(i, "weapon_shotgun", f);
    return;

    case DEVISTATORSPRITE:	//29	
		W_OtherItems(i, "weapon_gauss", f);
    return;

	case FREEZEAMMO:		//37	
		W_OtherItems(i, "ammo_gaussclip", f);
    return;

    case AMMO:				//40	
		W_OtherItems(i, "ammo_357", f);
    return;

    case BATTERYAMMO:		//41	
		W_OtherItems(i, "ammo_lightning", f); //Not sure what BatterAmmo is in Duke 3D, I'll find out.
    return;

    case RPGAMMO:		    //44	
		W_OtherItems(i, "ammo_rpgclip", f);
    return;

	case GROWAMMO:		    //45
	case CRYSTALAMMO:	    //46
	W_OtherItems(i, "ammo_9mmAR", f); //Again not too sure of these.
    return;

	case SHOTGUNAMMO:	    //49
		W_OtherItems(i, "ammo_buckshot", f);
    return;

	case COLA:				//51
		W_OtherItems(i, "item_antidote", f);
    return;

    case SIXPAK:			//52
		W_OtherItems(i, "item_battery", f);
    return;

	case FIRSTAID:			//53
		W_OtherItems(i, "item_healthkit", f);
    return;

	case SHIELD:			//54
		W_OtherItems(i, "item_armor_combat", f);
    return;
    
	case STEROIDS:			//55
		W_OtherItems(i, "item_armor_body", f);
    return;

	case AIRTANK:			//56
		W_OtherItems(i, "item_breather", f);
    return;

	case JETPACK:			//57
		W_OtherItems(i, "item_pack", f);
    return;

	case HEATSENSOR:		//59
	W_OtherItems(i, "item_silencer", f);
    return;

	case ACCESSCARD:		//60
	W_OtherItems(i, "key_blue_key", f);
    return;

	case BOOTS:				//61
	W_OtherItems(i, "item_enviro", f);
    return;

	case ATOMICHEALTH:		//100
	W_OtherItems(i, "item_health_mega", f);
    return;

	case HOLODUKE:			//1348
	W_OtherItems(i, "item_power_shield", f);
    return;

	case APLAYERTOP:		//1400
	case APLAYER:			//1405
	case PLAYERONWATER:		//1420 The player starts
		
		if (sprite[i].lotag == 1)
			W_OtherItems(i, "info_player_coop", f);
		else  
			W_OtherItems(i, "info_player_deathmatch", f);
		return;
 
	case   OOZFILTER:		//1079
	case     SEENINE:		//1247
	return;

	case MUSICANDSFX: 
	W_MusicanDSFX(i, "target_speaker", f); // TESTME:

	default:
    W_OtherItems(i, "fix_me", f); // Dummy entity
	} // switch

}